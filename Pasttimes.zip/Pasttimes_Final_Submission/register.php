```php
<?php
session_start();
require_once 'db.php'; // make sure this connects $conn

$message = "";

if (isset($_POST['register'])) {

    // Sanitize inputs
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    // Hash password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Check if email already exists
    $check = $conn->prepare("SELECT * FROM users WHERE Email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        $message = "Email already exists!";
    } else {
        // Insert user
        $stmt = $conn->prepare("INSERT INTO users (Name, Email, Password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $hashedPassword);

        if ($stmt->execute()) {
            $message = "Registered Successfully!";
        } else {
            $message = "Error: " . $conn->error;
        }

        $stmt->close();
    }

    $check->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Register</title>

<style>
body {
    font-family: Arial, sans-serif;
}

.registerdiv {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100vh;
    gap: 15px;
}

.shoplink {
    display: block;
    width: 120px;
    position: fixed;
    top: 20%;
    left: 45%;
    text-align: center;
    text-decoration: none;
    background-color: lightgreen;
    padding: 10px;
    border-radius: 5px;
}

.registerdiv input {
    padding: 12px;
    margin: 6px;
    width: 220px;
}

button {
    padding: 10px;
    width: 240px;
    background-color: green;
    color: white;
    border: none;
    cursor: pointer;
}

button:hover {
    background-color: darkgreen;
}

.message {
    color: green;
    font-weight: bold;
}
</style>
</head>

<body>

<a class="shoplink" href="index.php">Pastimes</a>

<div class="registerdiv">

    <?php if (!empty($message)) echo "<p class='message'>$message</p>"; ?>

    <form action="" method="post">
        <input name="username" placeholder="Username" required>
        <input name="email" type="email" placeholder="Email" required>
        <input name="password" type="password" placeholder="Password" required>
        <button type="submit" name="register">Register</button>
    </form>

</div>

</body>
</html>
```
