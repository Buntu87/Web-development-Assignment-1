<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if(isset($_GET['id'])){
    $id = $_GET['id'];

    // Check if already in cart
    $check_sql = "SELECT * FROM cart WHERE UserID = $user_id AND ProductID = $id";
    $check_result = mysqli_query($conn, $check_sql);

    if(mysqli_num_rows($check_result) == 0){
        // Add to cart
        mysqli_query($conn, "INSERT INTO cart(UserID, ProductID) VALUES($user_id, $id)");
        echo "Added to cart";
    } else {
        echo "Already in cart";
    }
}

// Display cart
$sql = "SELECT products.Name, products.Price, cart.Quantity FROM cart JOIN products ON cart.ProductID = products.ProductID WHERE cart.UserID = $user_id";
$result = mysqli_query($conn, $sql);

if(mysqli_num_rows($result) > 0){
    echo "<h2>Your Cart</h2>";
    echo "<ul>";
    while($row = mysqli_fetch_assoc($result)){
        echo "<li>" . $row['Name'] . " - $" . $row['Price'] . " (Qty: " . $row['Quantity'] . ")</li>";
    }
    echo "</ul>";
} else {
    echo "<p>Your cart is empty.</p>";
}
?>