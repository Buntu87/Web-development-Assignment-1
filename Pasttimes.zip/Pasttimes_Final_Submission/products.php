<?php
session_start();
require_once 'db.php';

$result = mysqli_query($conn, "SELECT * FROM products");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="header">
        <h2>Products</h2>
        <a href="index.php">Home</a> | <a href="cart.php">Cart</a> | <a href="login.php">Login</a> | <a href="register.php">Register</a>
    </div>

    <div class="container">
        <div class="content">
            <?php while($row = mysqli_fetch_assoc($result)){ ?>
            <div class="product">
                <?php echo $row['Name'] . " - $" . $row['Price']; ?>
                <a href='cart.php?id=<?php echo $row['ProductID']; ?>'>Add to Cart</a>
            </div>
            <?php } ?>
        </div>
    </div>
</body>
</html>