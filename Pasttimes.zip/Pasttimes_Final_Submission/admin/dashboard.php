<?php
session_abort();
if(isset($_SESSION["user_id"])){
    if($_SESSION['user_name'] == "admin"){

    }
    else{
        echo "go for usser dashboard";
    }
}
else{
    header("location: ../index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        Dashboard_sidebar{
            position: fixe;
            top:0;
            background-color: lightcyan;
            width: 200px;
            height: 100%
        }
        .dashboard_sidebar ul li{
            list-style: none;

        }
        .dashboard_sidebar ul li a{
            text-decoration: none;
            color: black;

        }
    </style>
</head>
<body>
    <div class="dashboard_sidebar">
        <ul>
           <li><a href="">Add Product</a> </li> 
           <li><a href="">View Order</a></li>
        </ul>

    </div>
</body>
</html>