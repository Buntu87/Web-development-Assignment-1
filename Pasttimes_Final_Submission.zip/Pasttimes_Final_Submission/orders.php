<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$result = mysqli_query($conn, "SELECT * FROM orders WHERE UserID = $user_id");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="header">
        <h2>My Orders</h2>
        <a href="index.php">Home</a> | <a href="cart.php">Cart</a> | <a href="logout.php">Logout</a>
    </div>

    <div class="container">
        <div class="content">
            <table border="1" width="100%">
                <tr>
                    <th>Order ID</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Total</th>
                </tr>

                <?php while($row = mysqli_fetch_assoc($result)){ ?>
                <tr>
                    <td><?php echo $row['OrderID']; ?></td>
                    <td><?php echo $row['OrderDate']; ?></td>
                    <td><?php echo $row['Status']; ?></td>
                    <td>$<?php echo $row['TotalAmount']; ?></td>
                </tr>
                <?php } ?>
            </table>
        </div>
    </div>
</body>
</html>