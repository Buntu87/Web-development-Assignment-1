<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$result = mysqli_query($conn, "SELECT * FROM orders WHERE UserID = $user_id");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="header">
        <h2>My Orders</h2>
        <div>
            <a href="index.php">Home</a> | <a href="cart.php">Cart</a> | <a href="logout.php">Logout</a>
        </div>
    </div>

    <div class="container">
        <aside class="sidebar">
            <div class="avatar">
                <img src="images/avatar.png" alt="avatar" onerror="this.src='images/avatar.png'">
                <div>
                    <h3><?php echo htmlspecialchars($_SESSION['user_name'] ?? 'User'); ?></h3>
                    <div class="small"><?php echo htmlspecialchars($_SESSION['user_email'] ?? ''); ?></div>
                </div>
            </div>
            <nav class="account-nav">
                <a href="image/dashboard.php">Dashboard</a>
                <a class="active" href="orders.php">Orders</a>
                <a href="#">Wishlist</a>
                <a href="#">Support tickets</a>
                <div style="margin-top:12px;border-top:1px solid #eef6ff;padding-top:12px;">
                    <a href="register.php">Profile info</a>
                    <a href="payments.php">Payment methods</a>
                    <a href="addresses.php">Addresses</a>
                </div>
            </nav>
        </aside>

        <main class="content">
            <div class="account-top">
                <h3>Orders history</h3>
                <div>
                    <label>Sort orders:</label>
                    <select>
                        <option>All</option>
                        <option>Delivered</option>
                        <option>In Progress</option>
                    </select>
                </div>
            </div>

            <table class="orders-table">
                <thead>
                    <tr>
                        <th>Order #</th>
                        <th>Date Purchased</th>
                        <th>Status</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                <?php while($row = mysqli_fetch_assoc($result)){
                    $status = strtolower($row['Status']);
                    $badgeClass = 'status-inprogress';
                    if (strpos($status,'cancel') !== false) $badgeClass = 'status-cancelled';
                    elseif (strpos($status,'deliver') !== false) $badgeClass = 'status-delivered';
                    elseif (strpos($status,'delay') !== false) $badgeClass = 'status-delayed';
                ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['OrderID']); ?></td>
                        <td><?php echo htmlspecialchars($row['OrderDate']); ?></td>
                        <td><span class="status-badge <?php echo $badgeClass; ?>"><?php echo htmlspecialchars($row['Status']); ?></span></td>
                        <td>R<?php echo number_format(floatval($row['TotalAmount']),2); ?></td>
                    </tr>
                <?php } ?>
                </tbody>
            </table>

        </main>
    </div>
</body>
</html>