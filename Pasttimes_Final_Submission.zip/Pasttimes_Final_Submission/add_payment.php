<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = intval($_SESSION['user_id']);
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cardType = trim($_POST['card_type'] ?? '');
    $cardNumber = trim($_POST['card_number'] ?? '');
    $nameOnCard = trim($_POST['name_on_card'] ?? '');
    $expiry = trim($_POST['expiry'] ?? '');

    try {
        $stmt = $conn->prepare("INSERT INTO payments (UserID, CardType, CardNumber, NameOnCard, Expiry) VALUES (?, ?, ?, ?, ?)");
        if (!$stmt) throw new Exception('Prepare failed: ' . $conn->error);
        $stmt->bind_param('issss', $user_id, $cardType, $cardNumber, $nameOnCard, $expiry);
        $ok = $stmt->execute();
        $stmt->close();

        if ($ok) {
            $_SESSION['message'] = 'Payment method added.';
            header('Location: payments.php');
            exit();
        } else {
            $message = 'Could not add payment method.';
        }
    } catch (mysqli_sql_exception $e) {
        // If the payments table doesn't exist, try to create it then retry once
        if (strpos($e->getMessage(), 'doesn\'t exist') !== false || strpos($e->getMessage(), 'no such table') !== false) {
            $create = "CREATE TABLE IF NOT EXISTS payments (
                PaymentID INT AUTO_INCREMENT PRIMARY KEY,
                UserID INT NOT NULL,
                CardType VARCHAR(50),
                CardNumber VARCHAR(128),
                NameOnCard VARCHAR(255),
                Expiry VARCHAR(20),
                CreatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                INDEX (UserID)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";
            $conn->query($create);
            // retry insert
            try {
                $stmt = $conn->prepare("INSERT INTO payments (UserID, CardType, CardNumber, NameOnCard, Expiry) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param('issss', $user_id, $cardType, $cardNumber, $nameOnCard, $expiry);
                $ok = $stmt->execute();
                $stmt->close();
                if ($ok) {
                    $_SESSION['message'] = 'Payment method added.';
                    header('Location: payments.php');
                    exit();
                }
            } catch (Exception $e2) {
                $message = 'Could not add payment method after creating table.';
            }
        } else {
            $message = 'Database error: ' . $e->getMessage();
        }
    } catch (Exception $e) {
        $message = 'Error: ' . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Add Payment Method</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .form-row { margin-bottom:12px; }
        label { display:block; margin-bottom:6px; font-weight:600; }
    </style>
</head>
<body>
    <div class="header"><h2>Add Payment Method</h2><div><a href="payments.php">Back</a></div></div>
    <div class="container">
        <div class="content">
            <?php if ($message): ?><p style="color:red"><?php echo htmlspecialchars($message); ?></p><?php endif; ?>
            <form method="post" action="add_payment.php">
                <div class="form-row">
                    <label>Card Type</label>
                    <input name="card_type" required placeholder="Visa, MasterCard, etc">
                </div>
                <div class="form-row">
                    <label>Card Number</label>
                    <input name="card_number" required placeholder="1234 5678 9012 3456">
                </div>
                <div class="form-row">
                    <label>Name on Card</label>
                    <input name="name_on_card" required>
                </div>
                <div class="form-row">
                    <label>Expiry (MM/YYYY)</label>
                    <input name="expiry" required placeholder="08/2026">
                </div>
                <div>
                    <button type="submit">Save</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>
