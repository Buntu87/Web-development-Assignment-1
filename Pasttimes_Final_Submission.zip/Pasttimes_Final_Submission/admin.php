<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION["user_id"]) || $_SESSION['user_name'] != "admin") {
    header("location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Admin Panel</h1>
    <nav>
        <ul>
            <li><a href="admin/dashboard.php">Dashboard</a></li>
            <li><a href="admin/displayproduct.php">Manage Products</a></li>
            <li><a href="orders.php">View Orders</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
    <p>Welcome, Admin!</p>
</body>
</html>