<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user_id = intval($_SESSION['user_id']);
$addresses = [];
try {
    $res = $conn->query("SELECT AddressID, Line1, Line2, City, State, PostalCode, Country FROM addresses WHERE UserID = $user_id");
    if ($res) {
        $addresses = $res->fetch_all(MYSQLI_ASSOC);
    }
} catch (mysqli_sql_exception $e) {
    // Table may not exist or other DB error — fall back to empty addresses list
    $addresses = [];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Addresses</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="header">
        <h2>My Addresses</h2>
        <div>
            <a href="index.php">Home</a> | <a href="logout.php">Logout</a>
        </div>
    </div>

    <div class="container">
        <aside class="sidebar">
            <div class="avatar">
                <img src="images/avatar.png" alt="avatar" onerror="this.src='images/avatar.png'">
                <div>
                    <h3><?php echo htmlspecialchars($_SESSION['user_name'] ?? 'User'); ?></h3>
                    <div class="small"><?php echo htmlspecialchars($_SESSION['user_email'] ?? ''); ?></div>
                </div>
            </div>
            <nav class="account-nav">
                <a href="image/dashboard.php">Dashboard</a>
                <a href="orders.php">Orders</a>
                <a href="payments.php">Payment methods</a>
                <a href="register.php">Profile info</a>
                <a class="active" href="addresses.php">Addresses</a>
            </nav>
        </aside>

        <main class="content">
            <h3>Your saved addresses</h3>
            <?php if (!empty($addresses)): ?>
                <ul>
                <?php foreach($addresses as $addr): ?>
                    <li style="margin-bottom:12px;padding:10px;border:1px solid #eef6ff;border-radius:8px;">
                        <?php echo htmlspecialchars($addr['Line1']); ?><br>
                        <?php if (!empty($addr['Line2'])) echo htmlspecialchars($addr['Line2']) . '<br>'; ?>
                        <?php echo htmlspecialchars($addr['City'] . ', ' . $addr['State'] . ' ' . $addr['PostalCode']); ?><br>
                        <?php echo htmlspecialchars($addr['Country']); ?><br>
                        <a href="edit_address.php?id=<?php echo intval($addr['AddressID']); ?>">Edit</a> |
                        <a href="delete_address.php?id=<?php echo intval($addr['AddressID']); ?>" style="color:#d9534f;">Delete</a>
                    </li>
                <?php endforeach; ?>
                </ul>
            <?php else: ?>
                <p>No saved addresses yet.</p>
            <?php endif; ?>

            <p><a href="add_address.php" class="button">Add new address</a></p>
        </main>
    </div>
</body>
</html>
