<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_name'] != 'admin') {
    header("Location: login.php");
    exit();
}

if(isset($_POST['add'])){
    $n = mysqli_real_escape_string($conn, $_POST['name']);
    $p = $_POST['price'];
    $s = $_POST['stock'];
    $sid = 1; // default seller

    mysqli_query($conn, "INSERT INTO products(Name, Price, Stock, SellerID) VALUES('$n', '$p', '$s', '$sid')");

    echo "Product Added";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Product</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="header">
        <h2>Upload Product</h2>
        <a href="admin.php">Admin Panel</a> | <a href="logout.php">Logout</a>
    </div>

    <div class="container">
        <div class="content">
            <form method="POST">
                <input name="name" placeholder="Item Name" required>
                <input name="price" type="number" step="0.01" placeholder="Price" required>
                <input name="stock" type="number" placeholder="Stock" required>
                <button name="add">Upload</button>
            </form>
        </div>
    </div>
</body>
</html>