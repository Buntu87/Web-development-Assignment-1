<?php
session_start();
include __DIR__ . '/../db.php';
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header('Location: ../login.php');
    exit();
}

$status = '';
$message = '';
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $product_id = (int) $_GET['id'];
    $stmt = $conn->prepare('DELETE FROM products WHERE ProductID = ?');
    if ($stmt === false) {
        $status = 'error';
        $message = 'Database error: ' . $conn->error;
    } else {
        $stmt->bind_param('i', $product_id);
        if ($stmt->execute()) {
            $status = 'success';
            $message = 'Deleted Successfully.';
        } else {
            $status = 'error';
            $message = 'Error deleting product: ' . $stmt->error;
        }
        $stmt->close();
    }
} else {
    $status = 'error';
    $message = 'Invalid product specified for deletion.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Delete Product</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 700px;
            margin: 40px auto;
            padding: 16px;
        }
        .message {
            padding: 16px;
            border-radius: 6px;
            margin-bottom: 20px;
        }
        .message.success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .message.error {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .back-link {
            display: inline-block;
            padding: 10px 16px;
            background-color: #007bff;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="message <?php echo $status === 'success' ? 'success' : 'error'; ?>">
        <?php echo htmlspecialchars($message); ?>
    </div>
    <a class="back-link" href="displayproduct.php">Back to product list</a>
</body>
</html>