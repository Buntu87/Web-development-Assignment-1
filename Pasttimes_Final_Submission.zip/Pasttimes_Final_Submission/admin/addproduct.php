<?php
session_start();
include __DIR__ . '/../db.php';
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header('Location: ../login.php');
    exit();
}
$message = '';
if (isset($_POST['submit'])) {
    $product_name = trim($_POST['product_name'] ?? '');
    $product_price_raw = trim($_POST['product_price'] ?? '');
    $product_price = is_numeric($product_price_raw) ? (float) $product_price_raw : null;
    $product_description = trim($_POST['product_description'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $imageName = '';

    if ($product_name === '' || $product_price_raw === '' || $product_price === null) {
        $message = 'Please fill in all required fields and enter a valid price.';
    } else {
        $targetDir = __DIR__ . '/../images/';
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0755, true);
        }

        if (isset($_FILES['image']['name']) && $_FILES['image']['name'] !== '' && ($_FILES['image']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
            $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'avif'];
            $imageExt = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            if (!in_array($imageExt, $allowedExtensions, true)) {
                $message = 'Invalid image file type. Allowed: jpg, jpeg, png, gif, webp, avif.';
            } else {
                $baseName = preg_replace('/[^A-Za-z0-9_-]+/', '_', trim($product_name));
                $imageName = $baseName . '.' . $imageExt;
                $targetFile = $targetDir . $imageName;
                if (!move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
                    $message = 'Image upload failed. Please try again.';
                }
            }
        }

        if ($message === '') {
            $stock = 0;
            $stmt = $conn->prepare('INSERT INTO products (Name, Price, Stock, SellerID) VALUES (?, ?, ?, NULL)');
            if ($stmt === false) {
                $message = 'Database error: ' . $conn->error;
            } else {
                $stmt->bind_param('sdi', $product_name, $product_price, $stock);
                if ($stmt->execute()) {
                    $message = 'New product added successfully.';
                } else {
                    $message = 'Error adding product: ' . $stmt->error;
                }
                $stmt->close();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        *{
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }

        .dashboard_sidebar{
            position: fixed;
            top:0;
            background-color: lightcyan;
            width: 200px;
            height: 100%;
        }
        .dashboard_sidebar ul li{
            list-style: none;

        }
        .dashboard_sidebar ul li a{
            padding: 10px;
            display: block;
            text-decoration: none;
            color: red;

        }
        .dashboard_sidebar ul li a:hover{
            background-color: black;
        }
        .dashboard_main{
            position: relative;
            left: 45%;
            padding: 30px;
            margin-top:200px;
            border-radius: 15px 50px;
        }
        .dashboard_main input{
            display: block;
            margin: 10px;
            color: red;
            padding: 20px;
        }
        .button{
            width: 15%;
            background-color: green;
            border-radius: 15px 50px;
            
        }
    </style>
</head>
<body>
    <div class="dashboard_sidebar">
        <ul>
           <li><a href="addproduct.php">Add Product</a> </li> 
           <li><a href="view_orders.php">View Order</a></li>
           <li><a href="logout.php">Logout</a>
        </ul>

    </div>
    <div class="dashboard_main">
        <div class="AddProduct">
            <?php if ($message): ?>
                <p><?php echo htmlspecialchars($message); ?></p>
            <?php endif; ?>
            <form action="addproduct.php" method="post" enctype="multipart/form-data">
                <label for="product_name">Product Name:</label>
                <input type="text" id="product_name" name="product_name" required>
                <br><br>
                <label for="product_price">Price:</label>
                <input type="number" id="product_price" name="product_price" step="0.01" required>
                <br><br>
                <label for="product_description">Description:</label>
                <textarea id="product_description" name="product_description"></textarea>
                <br><br>
                <h2>Upload Image</h2>
                <br><br>
                <input type="file" name="image">
                <br><br>
                <select name="category" required>
                    <option value="" disabled selected>Select a category</option>
                    <option value="clothing">Clothing</option>
                    <option value="home">Home</option>
                </select>
                <br><br>
                <input type="submit" name="submit" value="Add Product" class="button">
            </form>
        </div>
    </div>
</body>
</html>