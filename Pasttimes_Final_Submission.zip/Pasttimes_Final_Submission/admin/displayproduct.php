<?php
session_start();
include __DIR__ . '/../db.php';
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header('Location: ../login.php');
    exit();
}

function findImageByProductName($productName) {
    $baseName = preg_replace('/[^A-Za-z0-9_-]+/', '_', trim($productName));
    $dir = __DIR__ . '/../images/';
    $extensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'avif'];
    foreach ($extensions as $ext) {
        $fileName = $baseName . '.' . $ext;
        if (file_exists($dir . $fileName)) {
            return '../images/' . rawurlencode($fileName);
        }
    }
    return '';
}

$success_message = '';
$error_message = '';
$products = [];
$status = $_GET['status'] ?? '';
if ($status === 'deleted') {
    $success_message = 'Product deleted successfully.';
} elseif ($status === 'delete_error') {
    $error_message = 'Could not delete the product. Please try again.';
} elseif ($status === 'invalid_id') {
    $error_message = 'Invalid product specified for deletion.';
}

$result = $conn->query('SELECT ProductID, Name, Price, Stock, SellerID FROM products');
if ($result === false) {
    $error_message = 'Error fetching products: ' . $conn->error;
} else {
    $products = $result->fetch_all(MYSQLI_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display Products</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th {
            border-top: 4px solid darkblue;
            border-bottom: 2px solid blue;
            padding: 10px;
            background-color: #e0ecff;
        }
        td {
            padding: 10px;
            text-align: center;
            border-bottom: 2px solid blue;
            background-color: lightblue;
        }
        .update,
        .delete {
            display: inline-block;
            margin: 0 4px;
            padding: 8px 12px;
            color: #000;
            text-decoration: none;
            border-radius: 4px;
        }
        .update {
            background-color: lightgreen;
        }
        .delete {
            background-color: lightcoral;
        }
    </style>
</head>
<body>
    <h1>Product List</h1>
    <?php if ($success_message): ?>
        <div style="padding: 12px; margin: 16px 0; background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; border-radius: 4px;">
            <?php echo htmlspecialchars($success_message); ?>
        </div>
    <?php endif; ?>
    <?php if ($error_message): ?>
        <div style="padding: 12px; margin: 16px 0; background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; border-radius: 4px;">
            <?php echo htmlspecialchars($error_message); ?>
        </div>
    <?php endif; ?>
    <table>
        <thead>
            <tr>
                <th>ProductID</th>
                <th>Name</th>
                <th>Price</th>
                <th>Stock</th>
                <th>SellerID</th>
                <th colspan="2">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if ($error_message): ?>
                <tr>
                    <td colspan="7"><?php echo htmlspecialchars($error_message); ?></td>
                </tr>
            <?php elseif (empty($products)): ?>
                <tr>
                    <td colspan="7">No products found.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($products as $row): ?>
                    <?php $imageUrl = findImageByProductName($row['Name']); ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['ProductID']); ?></td>
                        <td>
                            <?php if ($imageUrl): ?>
                                <a href="<?php echo $imageUrl; ?>" target="_blank"><?php echo htmlspecialchars($row['Name']); ?></a>
                                <br>
                                <img src="<?php echo $imageUrl; ?>" alt="<?php echo htmlspecialchars($row['Name']); ?>" style="max-width:120px; max-height:120px; margin-top:8px; border:1px solid #ccc;">
                            <?php else: ?>
                                <?php echo htmlspecialchars($row['Name']); ?>
                            <?php endif; ?>
                        </td>
                        <td><?php echo htmlspecialchars($row['Price']); ?></td>
                        <td><?php echo htmlspecialchars($row['Stock']); ?></td>
                        <td><?php echo htmlspecialchars($row['SellerID']); ?></td>
                        <td><a class="update" href="updateproduct.php?id=<?php echo urlencode($row['ProductID']); ?>">Update</a></td>
                        <td><a class="delete" href="deleteproduct.php?id=<?php echo urlencode($row['ProductID']); ?>">Delete</a></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>