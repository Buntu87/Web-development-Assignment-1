<?php
session_start();
if (isset($_SESSION["user_id"])) {
    if ($_SESSION['user_name'] == "admin") {
        // allow admin access
    } else {
        header("Location: ../image/dashboard.php");
        exit();
    }
} else {
    header("Location: ../index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        .dashboard_sidebar{
            position: fixed;
            top:0;
            background-color: lightcyan;
            width: 200px;
            height: 100%
        }
        .dashboard_sidebar ul li{
            list-style: none;

        }
        .dashboard_sidebar ul li a{
            padding: 10px;
            display: block;
            text-decoration: none;
            color: red;

        }
        .dashboard_sidebar ul li a:hover{
            background-color: black;
        }
        .dashboard_main{
            margin-left: 200px;
            padding: 30px;
        }
    </style>
</head>
<body>
    <div class="dashboard_sidebar">
        <ul>
           <li><a href="addproduct.php">Add Product</a> </li> 
           <li><a href="displayproduct.php">View Products</a></li>
           <li><a href="view_orders.php">View Order</a></li>
           <li><a href="manage_users.php">Manage Users</a></li>
           <li><a href="view_seller_requests.php">Seller Requests</a></li>
           <li><a href="messages.php">Messages</a></li>
           <li><a href="logout.php">Logout</a>
        </ul>

    </div>
    <div class="dashboard_main">
        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolor accusantium a reprehenderit doloremque consequuntur mollitia sunt nemo quae quaerat saepe? Voluptatum pariatur nulla similique nesciunt aliquid cum natus maxime recusandae.
            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ex quasi ratione quaerat nesciunt, provident esse. Quia at soluta tempora aut reiciendis dolore totam, eaque adipisci perspiciatis optio nobis qui! Sit?
        </p>
    </div>
</body>
</html>