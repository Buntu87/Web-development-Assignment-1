<?php
session_start();
include __DIR__ . '/../db.php';

if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    header('Location: ../index.php');
    exit();
}

$message = '';
$product_id = null;
$product_name = '';
$product_price = '';
$product_description = '';
$category = '';
$imageName = '';
$image = '';
$tempImage = '';

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (isset($_GET['id']) && is_numeric($_GET['id'])) {
        $product_id = (int) $_GET['id'];
        $stmt = $conn->prepare('SELECT ProductID, Name, Price FROM products WHERE ProductID = ?');
        if ($stmt) {
            $stmt->bind_param('i', $product_id);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result && $result->num_rows === 1) {
                $row = $result->fetch_assoc();
                $product_name = $row['Name'];
                $product_price = $row['Price'];
            } else {
                $message = 'Product not found.';
            }
            $stmt->close();
        } else {
            $message = 'Database error: ' . $conn->error;
        }
    } else {
        $message = 'Missing product ID.';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = isset($_POST['product_id']) && is_numeric($_POST['product_id']) ? (int) $_POST['product_id'] : null;
    $product_name = trim($_POST['product_name'] ?? '');
    $product_price_raw = trim($_POST['product_price'] ?? '');
    $product_price = is_numeric($product_price_raw) ? (float) $product_price_raw : null;
    $product_description = trim($_POST['product_description'] ?? '');
    $category = trim($_POST['category'] ?? '');

    if ($product_id === null) {
        $message = 'Missing product ID.';
    } elseif ($product_name === '' || $product_price_raw === '' || $product_price === null) {
        $message = 'Please fill in all required fields and enter a valid price.';
    } else {
        $targetDir = __DIR__ . '/../images/';
        if (!is_dir($targetDir)) {
            mkdir($targetDir, 0755, true);
        }

        if (isset($_FILES['image']['name']) && $_FILES['image']['name'] !== '' && ($_FILES['image']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
            $allowedExtensions = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'avif'];
            $imageExt = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
            if (!in_array($imageExt, $allowedExtensions, true)) {
                $message = 'Invalid image file type. Allowed: jpg, jpeg, png, gif, webp, avif.';
            } else {
                $baseName = preg_replace('/[^A-Za-z0-9_-]+/', '_', trim($product_name));
                $imageName = $baseName . '.' . $imageExt;
                $image = $imageName;
                $tempImage = $_FILES['image']['tmp_name'];
                $targetFile = $targetDir . $imageName;
                if (!move_uploaded_file($tempImage, $targetFile)) {
                    $message = 'Image upload failed. Please try again.';
                }
            }
        }

        if ($message === '') {
            $stmt = $conn->prepare('UPDATE products SET Name = ?, Price = ? WHERE ProductID = ?');
            if ($stmt === false) {
                $message = 'Database error: ' . $conn->error;
            } else {
                $stmt->bind_param('sdi', $product_name, $product_price, $product_id);
                if ($stmt->execute()) {
                    $message = 'Product updated successfully.';
                    $sql3 = "SELECT * FROM products WHERE ProductID = {$product_id}";
                    $result3 = $conn->query($sql3);
                    $sql4 = "SELECT * FROM products";
                    $result4 = $conn->query($sql4);
                    header('Location: displayproduct.php');
                    exit();
                } else {
                    $message = 'Error updating product: ' . $stmt->error;
                }
                $stmt->close();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Product</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }

        .dashboard_sidebar {
            position: fixed;
            top: 0;
            background-color: lightcyan;
            width: 200px;
            height: 100%;
        }

        .dashboard_sidebar ul li {
            list-style: none;
        }

        .dashboard_sidebar ul li a {
            padding: 10px;
            display: block;
            text-decoration: none;
            color: red;
        }

        .dashboard_sidebar ul li a:hover {
            background-color: black;
        }

        .dashboard_main {
            position: relative;
            left: 45%;
            padding: 30px;
            margin-top: 200px;
            border-radius: 15px 50px;
        }

        .dashboard_main input,
        .dashboard_main textarea,
        .dashboard_main select {
            display: block;
            margin: 10px 0;
            color: red;
            padding: 10px;
            width: 100%;
            max-width: 400px;
        }

        .button {
            width: 15%;
            background-color: green;
            border-radius: 15px 50px;
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <div class="dashboard_sidebar">
        <ul>
            <li><a href="addproduct.php">Add Product</a></li>
            <li><a href="view_orders.php">View Order</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>
    <div class="dashboard_main">
        <div class="AddProduct">
            <?php if ($message): ?>
                <p><?php echo htmlspecialchars($message); ?></p>
            <?php endif; ?>
            <form action="updateproduct.php?id=<?php echo urlencode((int) $product_id); ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($product_id); ?>">

                <label for="product_name">Product Name:</label>
                <input type="text" id="product_name" name="product_name" value="<?php echo htmlspecialchars($product_name); ?>" required>

                <label for="product_price">Price:</label>
                <input type="number" id="product_price" name="product_price" step="0.01" value="<?php echo htmlspecialchars($product_price); ?>" required>

                <label for="product_description">Description:</label>
                <textarea id="product_description" name="product_description"><?php echo htmlspecialchars($product_description); ?></textarea>

                <label for="image">Upload Image:</label>
                <input type="file" id="image" name="image">

                <label for="category">Category:</label>
                <select id="category" name="category" required>
                    <option value="" disabled<?php echo $category === '' ? ' selected' : ''; ?>>Select a category</option>
                    <option value="clothing"<?php echo $category === 'clothing' ? ' selected' : ''; ?>>Clothing</option>
                    <option value="home"<?php echo $category === 'home' ? ' selected' : ''; ?>>Home</option>
                </select>

                <input type="submit" name="submit" value="Update Product" class="button">
            </form>
        </div>
    </div>
</body>
</html>