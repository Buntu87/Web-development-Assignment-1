<?php
session_start();
// Basic image upload helper for local development.
// Use this to upload an image into the images/ folder and name it (e.g., p1.jpg).

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image']) && isset($_POST['name'])) {
    $name = preg_replace('/[^A-Za-z0-9_-]/', '', $_POST['name']);
    $uploadDir = __DIR__ . '/../images/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

    $file = $_FILES['image'];
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $msg = 'Upload error';
    } else {
        $ext = pathinfo($file['name'], PATHINFO_EXTENSION);
        $ext = strtolower($ext);
        $allowed = ['jpg','jpeg','png','gif','webp','avif'];
        if (!in_array($ext, $allowed)) {
            $msg = 'Invalid file type';
        } else {
            $target = $uploadDir . $name . '.' . $ext;
            if (move_uploaded_file($file['tmp_name'], $target)) {
                $msg = 'Uploaded as images/' . $name . '.' . $ext;
            } else {
                $msg = 'Could not move uploaded file';
            }
        }
    }
}
?>
<!doctype html>
<html>
<head><meta charset="utf-8"><title>Upload Image</title></head>
<body>
<h1>Upload Image</h1>
<?php if (!empty($msg)): ?><p><?php echo htmlspecialchars($msg); ?></p><?php endif; ?>
<form method="post" enctype="multipart/form-data">
    <label>Target name (no extension): <input name="name" required></label><br><br>
    <label>Image file: <input type="file" name="image" accept="image/*" required></label><br><br>
    <button type="submit">Upload</button>
</form>
<p>Example: set name to <strong>p1</strong> and upload your blazer image, then visit <a href="../products.php">Products</a>.</p>
</body>
</html>
