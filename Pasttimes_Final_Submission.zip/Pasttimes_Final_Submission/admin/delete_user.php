<?php
session_start();
require_once __DIR__ . '/../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 1) {
    header('Location: ../login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['user_id'])) {
    $uid = intval($_POST['user_id']);
    $stmt = $conn->prepare("DELETE FROM users WHERE UserID = ?");
    $stmt->bind_param('i', $uid);
    $stmt->execute();
    $stmt->close();
    $_SESSION['message'] = 'User deleted.';
}
header('Location: manage_users.php');
exit();
?>