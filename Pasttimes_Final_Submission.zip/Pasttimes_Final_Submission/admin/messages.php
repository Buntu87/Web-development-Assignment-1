<?php
session_start();
require_once __DIR__ . '/../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 1) {
    header('Location: ../login.php');
    exit();
}

// Send message
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_message'])) {
    $receiver = intval($_POST['receiver']);
    $content = trim($_POST['content']);
    $sender = intval($_SESSION['user_id']);
    if ($content !== '') {
        $stmt = $conn->prepare("INSERT INTO messages (SenderID, ReceiverID, Content) VALUES (?, ?, ?)");
        $stmt->bind_param('iis', $sender, $receiver, $content);
        $stmt->execute();
        $stmt->close();
        $_SESSION['message'] = 'Message sent.';
        header('Location: messages.php');
        exit();
    }
}

$users = $conn->query("SELECT UserID, Name, Email FROM users ORDER BY UserID ASC");
$sent = $conn->query("SELECT m.*, s.Name AS SenderName, r.Name AS ReceiverName FROM messages m LEFT JOIN users s ON m.SenderID = s.UserID LEFT JOIN users r ON m.ReceiverID = r.UserID ORDER BY m.Timestamp DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Admin Messages</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <div class="header"><h2>Admin Messages</h2><a href="dashboard.php">Admin Dashboard</a></div>
    <div class="container">
        <?php if (!empty($_SESSION['message'])) { echo '<p style="color:green">' . htmlspecialchars($_SESSION['message']) . '</p>'; unset($_SESSION['message']); } ?>
        <form method="post" action="messages.php" style="max-width:700px;">
            <label>Send To:<br>
                <select name="receiver" required>
                    <?php while($u = $users->fetch_assoc()): ?>
                        <option value="<?php echo $u['UserID']; ?>"><?php echo htmlspecialchars($u['Name']) . ' (' . htmlspecialchars($u['Email']) . ')'; ?></option>
                    <?php endwhile; ?>
                </select>
            </label><br><br>
            <label>Message:<br>
                <textarea name="content" rows="4" style="width:100%;" required></textarea>
            </label><br><br>
            <button type="submit" name="send_message" value="1">Send</button>
        </form>

        <h3>All Messages</h3>
        <table border="1" cellpadding="8" style="border-collapse:collapse;max-width:1000px;width:100%;">
            <tr><th>Time</th><th>From</th><th>To</th><th>Content</th></tr>
            <?php while($row = $sent->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['Timestamp']; ?></td>
                <td><?php echo htmlspecialchars($row['SenderName']); ?></td>
                <td><?php echo htmlspecialchars($row['ReceiverName']); ?></td>
                <td><?php echo nl2br(htmlspecialchars($row['Content'])); ?></td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>