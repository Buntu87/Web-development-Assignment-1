<?php
// Reuse the root logout logic so /admin/logout.php exists and behaves identically
require_once __DIR__ . '/../logout.php';
?>
