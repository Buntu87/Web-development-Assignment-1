<?php
session_start();
require_once __DIR__ . '/../db.php';

// Basic admin guard — you may replace with proper admin checks
// For now, assume any logged-in user with id=1 is admin
if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 1) {
    header('Location: ../login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_user'])) {
    $uid = intval($_POST['user_id']);
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $stmt = $conn->prepare("UPDATE users SET Name = ?, Email = ? WHERE UserID = ?");
    $stmt->bind_param('ssi', $name, $email, $uid);
    $stmt->execute();
    $stmt->close();
    $_SESSION['message'] = 'User updated.';
    header('Location: manage_users.php');
    exit();
}

$users = $conn->query("SELECT UserID, Name, Email FROM users ORDER BY UserID ASC");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Manage Users</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <div class="header"><h2>Manage Users</h2><a href="dashboard.php">Admin Dashboard</a></div>
    <div class="container">
        <?php if (!empty($_SESSION['message'])) { echo '<p style="color:green">' . htmlspecialchars($_SESSION['message']) . '</p>'; unset($_SESSION['message']); } ?>
        <table border="1" cellpadding="8" style="border-collapse:collapse;max-width:900px;width:100%;">
            <tr><th>ID</th><th>Name</th><th>Email</th><th>Actions</th></tr>
            <?php while($row = $users->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['UserID']; ?></td>
                <td><?php echo htmlspecialchars($row['Name']); ?></td>
                <td><?php echo htmlspecialchars($row['Email']); ?></td>
                <td>
                    <form method="post" action="manage_users.php" style="display:inline-block;margin:0 6px 6px 0;">
                        <input type="hidden" name="user_id" value="<?php echo $row['UserID']; ?>">
                        <input type="text" name="name" value="<?php echo htmlspecialchars($row['Name']); ?>" required>
                        <input type="email" name="email" value="<?php echo htmlspecialchars($row['Email']); ?>" required>
                        <button type="submit" name="update_user" value="1">Save</button>
                    </form>
                    <form method="post" action="delete_user.php" style="display:inline-block;margin:0;">
                        <input type="hidden" name="user_id" value="<?php echo $row['UserID']; ?>">
                        <button type="submit" style="background:#d9534f;color:#fff;border:none;padding:6px 10px;border-radius:6px;">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>