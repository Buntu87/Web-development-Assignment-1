<?php
session_start();
include __DIR__ . '/../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_name'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

$sql = "SELECT o.OrderID, o.OrderDate, o.Status, o.TotalAmount, u.Name AS UserName, u.Email
        FROM orders o
        LEFT JOIN users u ON o.UserID = u.UserID
        ORDER BY o.OrderDate DESC";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Orders</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .dashboard_sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 200px;
            height: 100%;
            background-color: lightcyan;
            padding-top: 20px;
        }
        .dashboard_sidebar ul {
            padding: 0;
            margin: 0;
            list-style: none;
        }
        .dashboard_sidebar ul li {
            margin: 0;
        }
        .dashboard_sidebar ul li a {
            display: block;
            padding: 12px 16px;
            color: #333;
            text-decoration: none;
        }
        .dashboard_sidebar ul li a:hover {
            background-color: #ddd;
        }
        .dashboard_main {
            margin-left: 220px;
            padding: 30px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: #fff;
        }
        th, td {
            padding: 12px 10px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background: #0077cc;
            color: #fff;
        }
        tr:nth-child(even) {
            background: #f9f9f9;
        }
    </style>
</head>
<body>
    <div class="dashboard_sidebar">
        <ul>
            <li><a href="addproduct.php">Add Product</a></li>
            <li><a href="displayproduct.php">View Products</a></li>
            <li><a href="view_orders.php">View Order</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </div>
    <div class="dashboard_main">
        <h1>Orders</h1>
        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>User</th>
                    <th>Email</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result && mysqli_num_rows($result) > 0): ?>
                    <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['OrderID']); ?></td>
                            <td><?php echo htmlspecialchars($row['UserName'] ?? 'Guest'); ?></td>
                            <td><?php echo htmlspecialchars($row['Email'] ?? ''); ?></td>
                            <td><?php echo htmlspecialchars($row['OrderDate']); ?></td>
                            <td><?php echo htmlspecialchars($row['Status']); ?></td>
                            <td>R<?php echo htmlspecialchars(number_format($row['TotalAmount'], 2)); ?></td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">No orders found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
