<?php
session_start();
require_once __DIR__ . '/../db.php';

if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 1) {
    header('Location: ../index.php');
    exit();
}

// Approve request -> optionally move to products
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['approve']) && isset($_POST['request_id'])) {
    $rid = intval($_POST['request_id']);
    // Mark as Approved
    $stmt = $conn->prepare("UPDATE seller_requests SET Status = 'Approved' WHERE RequestID = ?");
    $stmt->bind_param('i', $rid);
    $stmt->execute();
    $stmt->close();
    $_SESSION['message'] = 'Request approved.';
    header('Location: view_seller_requests.php');
    exit();
}

$result = $conn->query("SELECT * FROM seller_requests ORDER BY CreatedAt DESC");
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Seller Requests</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <div class="header"><h2>Seller Requests</h2><a href="dashboard.php">Admin Dashboard</a></div>
    <div class="container">
        <?php if (!empty($_SESSION['message'])) { echo '<p style="color:green">' . htmlspecialchars($_SESSION['message']) . '</p>'; unset($_SESSION['message']); } ?>
        <table border="1" cellpadding="8" style="border-collapse:collapse;max-width:1000px;width:100%;">
            <tr><th>ID</th><th>Name</th><th>Brand</th><th>Description</th><th>Image</th><th>Status</th><th>Actions</th></tr>
            <?php while($row = $result->fetch_assoc()): ?>
            <tr>
                <td><?php echo $row['RequestID']; ?></td>
                <td><?php echo htmlspecialchars($row['Name']); ?></td>
                <td><?php echo htmlspecialchars($row['Brand']); ?></td>
                <td style="max-width:300px;"><?php echo nl2br(htmlspecialchars($row['Description'])); ?></td>
                <td><?php if ($row['ImagePath']) { echo '<img src="../' . htmlspecialchars($row['ImagePath']) . '" style="max-width:120px;">'; } ?></td>
                <td><?php echo htmlspecialchars($row['Status']); ?></td>
                <td>
                    <form method="post" action="view_seller_requests.php" style="display:inline-block;margin:0;">
                        <input type="hidden" name="request_id" value="<?php echo $row['RequestID']; ?>">
                        <button type="submit" name="approve" value="1" style="padding:6px 8px;background:#28a745;color:#fff;border:none;border-radius:6px;">Approve</button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</body>
</html>