<?php
session_start();
require_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $brand = trim($_POST['brand'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $user_id = $_SESSION['user_id'] ?? null;

    $imagePath = null;
    if (!empty($_FILES['image']['name'])) {
        $uploadsDir = __DIR__ . '/images/';
        if (!is_dir($uploadsDir)) mkdir($uploadsDir, 0755, true);
        $tmp = $_FILES['image']['tmp_name'];
        $orig = basename($_FILES['image']['name']);
        $ext = pathinfo($orig, PATHINFO_EXTENSION);
        $safeName = uniqid('sr_') . '.' . $ext;
        $dest = $uploadsDir . $safeName;
        if (move_uploaded_file($tmp, $dest)) {
            $imagePath = 'images/' . $safeName;
        }
    }

    if ($name !== '') {
        // Ensure the seller_requests table exists (helps avoid fatal errors if DB not imported)
        try {
            $createSql = "CREATE TABLE IF NOT EXISTS seller_requests (
                RequestID INT AUTO_INCREMENT PRIMARY KEY,
                UserID INT NULL,
                Name VARCHAR(150) NOT NULL,
                Brand VARCHAR(100),
                Description TEXT,
                ImagePath VARCHAR(255),
                Status VARCHAR(50) DEFAULT 'Pending',
                CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (UserID) REFERENCES users(UserID) ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
            $conn->query($createSql);
        } catch (Exception $e) {
            // If creation fails, log and continue — prepare() will fail later and be handled below
            error_log('Could not ensure seller_requests table exists: ' . $e->getMessage());
        }

        // Attempt insert; if UserID is null use NULL variant
        if ($user_id === null) {
            $stmt = $conn->prepare("INSERT INTO seller_requests (UserID, Name, Brand, Description, ImagePath) VALUES (NULL, ?, ?, ?, ?)");
            $stmt->bind_param('ssss', $name, $brand, $description, $imagePath);
        } else {
            $stmt = $conn->prepare("INSERT INTO seller_requests (UserID, Name, Brand, Description, ImagePath) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param('issss', $user_id, $name, $brand, $description, $imagePath);
        }

        if ($stmt === false) {
            error_log('sell_request prepare failed: ' . $conn->error);
            $_SESSION['message'] = 'Server error. Please try again later.';
            header('Location: sell_request.php');
            exit();
        }

        $stmt->execute();
        $stmt->close();

        $_SESSION['message'] = 'Request submitted. Admin will review it soon.';
        header('Location: sell_request.php');
        exit();
    } else {
        $error = 'Please provide an item name.';
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Sell an Item</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="header"><h2>Sell an Item</h2><a href="index.php">Home</a> | <a href="products.php">Products</a></div>
    <div class="container">
        <?php if (!empty($_SESSION['message'])) { echo '<p style="color:green">' . htmlspecialchars($_SESSION['message']) . '</p>'; unset($_SESSION['message']); } ?>
        <?php if (!empty($error)) { echo '<p style="color:red">' . htmlspecialchars($error) . '</p>'; } ?>
        <form method="post" action="sell_request.php" enctype="multipart/form-data" style="max-width:600px;">
            <label>Item Name:<br><input type="text" name="name" required style="width:100%;padding:8px;"></label><br><br>
            <label>Brand:<br><input type="text" name="brand" style="width:100%;padding:8px;"></label><br><br>
            <label>Description:<br><textarea name="description" rows="6" style="width:100%;padding:8px;"></textarea></label><br><br>
            <label>Image:<br><input type="file" name="image" accept="image/*"></label><br><br>
            <button type="submit" style="padding:10px 14px;background:#0b58e0;color:#fff;border:none;border-radius:6px;">Submit Request</button>
        </form>
    </div>
</body>
</html>