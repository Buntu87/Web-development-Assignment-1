<?php
session_start();
require_once 'db.php';

// Allow guest/session cart items in addition to DB-backed cart.
if (!isset($_SESSION['user_id'])) {
    // For site usability, we allow adding to a session cart even for guests.
    // (You can keep current behavior of redirecting to login by uncommenting below)
    // header("Location: login.php");
    // exit();
}

// Add item via POST (from products.php)
// Handle bulk add (Add All) where name[], price[], product_id[] are submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_all']) && isset($_POST['name']) && is_array($_POST['name'])) {
    if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
    $names = $_POST['name'];
    $prices = $_POST['price'] ?? [];
    $pids = $_POST['product_id'] ?? [];
    for ($i = 0; $i < count($names); $i++) {
        $name = strip_tags($names[$i]);
        $price = strip_tags($prices[$i] ?? 'R0');
        $product_id = $pids[$i] ?? uniqid('p_');
        if (isset($_SESSION['cart'][$product_id])) {
            $_SESSION['cart'][$product_id]['qty'] += 1;
        } else {
            $_SESSION['cart'][$product_id] = ['name' => $name, 'price' => $price, 'qty' => 1];
        }
    }
    header('Location: products.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['name']) && isset($_POST['price'])) {
    $name = strip_tags($_POST['name']);
    $price = strip_tags($_POST['price']);
    $product_id = $_POST['product_id'] ?? uniqid('p_');

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id]['qty'] += 1;
    } else {
        $_SESSION['cart'][$product_id] = ['name' => $name, 'price' => $price, 'qty' => 1];
    }

    // Redirect back to products page after adding
    header('Location: products.php');
    exit();
}

// Handle "Sell All" action: create an order from the session cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sell_all'])) {
    // Must be logged in to place an order
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit();
    }

    if (empty($_SESSION['cart'])) {
        $_SESSION['message'] = 'Cart is empty.';
        header('Location: cart.php');
        exit();
    }

    $user_id = intval($_SESSION['user_id']);

    // Calculate total amount
    $total = 0.0;
    foreach ($_SESSION['cart'] as $pid => $item) {
        // Normalize price string to float (remove non-numeric except dot)
        $priceFloat = floatval(preg_replace('/[^0-9\.]/', '', $item['price']));
        $qty = intval($item['qty']);
        $total += $priceFloat * max(1, $qty);
    }

    // Insert order and order items inside a transaction
    $conn->begin_transaction();
    try {
        $stmt = $conn->prepare("INSERT INTO orders (UserID, Status, TotalAmount) VALUES (?, ?, ?)");
        $status = 'Placed';
        $stmt->bind_param('isd', $user_id, $status, $total);
        $stmt->execute();
        $orderId = $conn->insert_id;
        $stmt->close();

        $itemStmtWithProd = $conn->prepare("INSERT INTO orderItems (OrderID, ProductID, Quantity, Price) VALUES (?, ?, ?, ?)");
        $itemStmtNoProd = $conn->prepare("INSERT INTO orderItems (OrderID, ProductID, Quantity, Price) VALUES (?, NULL, ?, ?)");
        foreach ($_SESSION['cart'] as $pid => $item) {
            $priceFloat = floatval(preg_replace('/[^0-9\.]/', '', $item['price']));
            $qty = intval($item['qty']);

            if (is_numeric($pid)) {
                $prodId = intval($pid);
                $itemStmtWithProd->bind_param('iiid', $orderId, $prodId, $qty, $priceFloat);
                $itemStmtWithProd->execute();

                // Optionally decrement stock if a numeric product id exists
                $conn->query("UPDATE products SET Stock = GREATEST(0, Stock - $qty) WHERE ProductID = $prodId");
            } else {
                $itemStmtNoProd->bind_param('iid', $orderId, $qty, $priceFloat);
                $itemStmtNoProd->execute();
            }
        }
        $itemStmtWithProd->close();
        $itemStmtNoProd->close();

        $conn->commit();

        // Clear session cart
        unset($_SESSION['cart']);

        header('Location: orders.php');
        exit();
    } catch (Exception $e) {
        $conn->rollback();
        error_log('Sell All error: ' . $e->getMessage());
        $_SESSION['message'] = 'Could not process order. Please try again.';
        header('Location: cart.php');
        exit();
    }
}

// Update quantity for an item in the session cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_qty']) && isset($_POST['product_key'])) {
    $key = $_POST['product_key'];
    $qty = max(0, intval($_POST['quantity'] ?? 1));
    if (isset($_SESSION['cart'][$key])) {
        if ($qty === 0) {
            unset($_SESSION['cart'][$key]);
        } else {
            $_SESSION['cart'][$key]['qty'] = $qty;
        }
    }
    header('Location: cart.php');
    exit();
}

// Remove an item from the session cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['remove_item']) && isset($_POST['product_key'])) {
    $key = $_POST['product_key'];
    if (isset($_SESSION['cart'][$key])) {
        unset($_SESSION['cart'][$key]);
    }
    header('Location: cart.php');
    exit();
}

// If user is logged in and prefers DB-backed cart, you can merge session cart into DB here.

// Display cart (session-based first)
echo "<h2>Your Cart</h2>";
if (!empty($_SESSION['cart'])) {
    echo '<table border="1" cellpadding="8" style="width:100%;max-width:800px;border-collapse:collapse;">';
    echo '<tr><th>Item</th><th>Price</th><th>Quantity</th><th>Actions</th></tr>';
    $subtotal = 0.0;
    foreach ($_SESSION['cart'] as $pid => $item) {
        $price = htmlspecialchars($item['price']);
        $qty = intval($item['qty']);
        $priceFloat = floatval(preg_replace('/[^0-9\.]/', '', $item['price']));
        $lineTotal = $priceFloat * max(1, $qty);
        $subtotal += $lineTotal;

        echo '<tr>';
        echo '<td>' . htmlspecialchars($item['name']) . '</td>';
        echo '<td>' . $price . '</td>';
        echo '<td style="width:140px;">';
        echo '<form method="post" action="cart.php" style="display:inline-block;margin:0;">';
        echo '<input type="hidden" name="product_key" value="' . htmlspecialchars($pid) . '">';
        echo '<input type="number" name="quantity" value="' . $qty . '" min="0" style="width:64px;padding:6px;margin-right:6px;">';
        echo '<button type="submit" name="update_qty" value="1">Update</button>';
        echo '</form>';
        echo '</td>';
        echo '<td>';
        echo '<form method="post" action="cart.php" style="display:inline-block;margin:0;">';
        echo '<input type="hidden" name="product_key" value="' . htmlspecialchars($pid) . '">';
        echo '<button type="submit" name="remove_item" value="1" style="background:#d9534f;color:#fff;border:none;padding:6px 10px;border-radius:6px;">Remove</button>';
        echo '</form>';
        echo '</td>';
        echo '</tr>';
    }
    echo '<tr><td colspan="3" style="text-align:right;font-weight:bold;padding:8px;">Subtotal:</td><td>R' . number_format($subtotal,2) . '</td></tr>';
    echo '</table>';

    echo '<div style="margin-top:12px;">';
    echo '<a href="products.php" style="display:inline-block;padding:8px 12px;background:#6c757d;color:#fff;border-radius:6px;text-decoration:none;margin-right:8px;">Continue Shopping</a>';
    if (isset($_SESSION['user_id'])) {
        echo '<form method="post" action="cart.php" style="display:inline-block;margin:0;">';
        echo '<input type="hidden" name="sell_all" value="1">';
        echo '<button type="submit" style="padding:8px 12px;background:#0b58e0;color:#fff;border:none;border-radius:6px;">Checkout</button>';
        echo '</form>';
    } else {
        echo '<a href="login.php" style="display:inline-block;padding:8px 12px;background:#0b58e0;color:#fff;border-radius:6px;text-decoration:none;margin-left:8px;">Login to Checkout</a>';
    }
    echo '</div>';

} else {
    // Fallback to DB-backed cart for logged-in users
    if (isset($_SESSION['user_id'])) {
        $user_id = intval($_SESSION['user_id']);
        $sql = "SELECT products.Name, products.Price, cart.Quantity FROM cart JOIN products ON cart.ProductID = products.ProductID WHERE cart.UserID = $user_id";
        $result = mysqli_query($conn, $sql);
        if ($result && mysqli_num_rows($result) > 0) {
            echo "<ul>";
            while($row = mysqli_fetch_assoc($result)){
                echo "<li>" . htmlspecialchars($row['Name']) . " - R" . htmlspecialchars($row['Price']) . " (Qty: " . intval($row['Quantity']) . ")</li>";
            }
            echo "</ul>";
        } else {
            echo "<p>Your cart is empty.</p>";
        }
    } else {
        echo "<p>Your cart is empty.</p>";
    }
}
?>