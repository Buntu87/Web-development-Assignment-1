<?php
session_start();
require_once 'db.php';

// Allow guest/session cart items in addition to DB-backed cart.
if (!isset($_SESSION['user_id'])) {
    // For site usability, we allow adding to a session cart even for guests.
    // (You can keep current behavior of redirecting to login by uncommenting below)
    // header("Location: login.php");
    // exit();
}

// Add item via POST (from products.php)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['name']) && isset($_POST['price'])) {
    $name = strip_tags($_POST['name']);
    $price = strip_tags($_POST['price']);
    $product_id = $_POST['product_id'] ?? uniqid('p_');

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    if (isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id]['qty'] += 1;
    } else {
        $_SESSION['cart'][$product_id] = ['name' => $name, 'price' => $price, 'qty' => 1];
    }

    // Redirect back to products page after adding
    header('Location: products.php');
    exit();
}

// If user is logged in and prefers DB-backed cart, you can merge session cart into DB here.

// Display cart (session-based first)
echo "<h2>Your Cart</h2>";
if (!empty($_SESSION['cart'])) {
    echo "<ul>";
    foreach ($_SESSION['cart'] as $pid => $item) {
        echo "<li>" . htmlspecialchars($item['name']) . " - " . htmlspecialchars($item['price']) . " (Qty: " . intval($item['qty']) . ")</li>";
    }
    echo "</ul>";
} else {
    // Fallback to DB-backed cart for logged-in users
    if (isset($_SESSION['user_id'])) {
        $user_id = intval($_SESSION['user_id']);
        $sql = "SELECT products.Name, products.Price, cart.Quantity FROM cart JOIN products ON cart.ProductID = products.ProductID WHERE cart.UserID = $user_id";
        $result = mysqli_query($conn, $sql);
        if ($result && mysqli_num_rows($result) > 0) {
            echo "<ul>";
            while($row = mysqli_fetch_assoc($result)){
                echo "<li>" . htmlspecialchars($row['Name']) . " - R" . htmlspecialchars($row['Price']) . " (Qty: " . intval($row['Quantity']) . ")</li>";
            }
            echo "</ul>";
        } else {
            echo "<p>Your cart is empty.</p>";
        }
    } else {
        echo "<p>Your cart is empty.</p>";
    }
}
?>