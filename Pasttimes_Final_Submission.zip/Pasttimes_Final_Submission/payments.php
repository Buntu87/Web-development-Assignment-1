<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$result = mysqli_query($conn, "SELECT * FROM payments WHERE UserID = $user_id");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Payment Methods</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="header">
        <h2>My Payment Methods</h2>
        <a href="index.php">Home</a> | <a href="cart.php">Cart</a> | <a href="logout.php">Logout</a>
    </div>

    <div class="container">
        <div class="content">
            <?php while($row = mysqli_fetch_assoc($result)){ ?>
            <div class="card">
                <strong><?php echo $row['CardType']; ?></strong><br>
                Card: **** **** **** <?php echo substr($row['CardNumber'], -4); ?><br>
                Name: <?php echo $row['NameOnCard']; ?><br>
                Expiry: <?php echo $row['Expiry']; ?>
            </div>
            <?php } ?>

            <button>Add Payment Method</button>
        </div>
    </div>
</body>
</html>