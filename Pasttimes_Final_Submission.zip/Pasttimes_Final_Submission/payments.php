<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

$result = mysqli_query($conn, "SELECT * FROM payments WHERE UserID = $user_id");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Payment Methods</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="header">
        <h2>My Payment Methods</h2>
        <div>
            <a href="index.php">Home</a> | <a href="cart.php">Cart</a> | <a href="logout.php">Logout</a>
        </div>
    </div>

    <div class="container">
        <aside class="sidebar">
            <div class="avatar">
                <img src="images/avatar.png" alt="avatar" onerror="this.src='images/avatar.png'">
                <div>
                    <h3><?php echo htmlspecialchars($_SESSION['user_name'] ?? 'User'); ?></h3>
                    <div class="small"><?php echo htmlspecialchars($_SESSION['user_email'] ?? ''); ?></div>
                </div>
            </div>
            <nav class="account-nav">
                <a href="image/dashboard.php">Dashboard</a>
                <a href="orders.php">Orders</a>
                <a href="#">Wishlist</a>
                <a href="#">Support tickets</a>
                <div style="margin-top:12px;border-top:1px solid #eef6ff;padding-top:12px;">
                    <a href="register.php">Profile info</a>
                    <a class="active" href="payments.php">Payment methods</a>
                    <a href="addresses.php">Addresses</a>
                </div>
            </nav>
        </aside>

        <main class="content">
            <div class="account-top">
                <h3>Primary payment method is used by default</h3>
                <div>
                    <button onclick="location.href='add_payment.php'">Add payment method</button>
                </div>
            </div>

            <div class="payments-list">
            <?php while($row = mysqli_fetch_assoc($result)){ ?>
                <div class="method">
                    <div class="left">
                        <div style="width:48px;height:32px;background:#fff;border-radius:6px;display:flex;align-items:center;justify-content:center;border:1px solid #eef6ff;"><?php echo htmlspecialchars($row['CardType']); ?></div>
                        <div>
                            <div><strong><?php echo $row['CardType']; ?> ending in <?php echo substr($row['CardNumber'],-4); ?></strong></div>
                            <div class="meta">Name: <?php echo htmlspecialchars($row['NameOnCard']); ?> &nbsp; • &nbsp; Expires: <?php echo htmlspecialchars($row['Expiry']); ?></div>
                        </div>
                    </div>
                    <div>
                        <a href="edit_payment.php?id=<?php echo intval($row['PaymentID']); ?>">Edit</a>
                        &nbsp; &nbsp;
                        <a href="delete_payment.php?id=<?php echo intval($row['PaymentID']); ?>" style="color:#d9534f;">Delete</a>
                    </div>
                </div>
            <?php } ?>
            </div>

        </main>
    </div>
</body>
</html>