<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$user = intval($_SESSION['user_id']);
$sql = "SELECT m.*, s.Name AS SenderName FROM messages m LEFT JOIN users s ON m.SenderID = s.UserID WHERE m.ReceiverID = $user ORDER BY m.Timestamp DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Messages</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="header"><h2>Messages</h2><a href="index.php">Home</a></div>
    <div class="container">
        <h3>Your Messages</h3>
        <?php if ($result && $result->num_rows > 0): ?>
            <ul>
                <?php while($row = $result->fetch_assoc()): ?>
                    <li><strong><?php echo htmlspecialchars($row['SenderName'] ?: 'Admin'); ?></strong> (<?php echo $row['Timestamp']; ?>):<br><?php echo nl2br(htmlspecialchars($row['Content'])); ?></li>
                <?php endwhile; ?>
            </ul>
        <?php else: ?>
            <p>No messages.</p>
        <?php endif; ?>
    </div>
</body>
</html>