-- ==============================
-- CREATE & USE DATABASE SAFELY
-- ==============================

CREATE DATABASE IF NOT EXISTS clothestoredbwitherd
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;
USE clothestoredbwitherd;

-- ==============================
-- DROP TABLES (prevents errors on re-import)
-- ==============================
DROP TABLE IF EXISTS orderItems;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS sellers;
DROP TABLE IF EXISTS messages;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS cart;
DROP TABLE IF EXISTS payments;

-- ==============================
-- USERS TABLE
-- ==============================
CREATE TABLE users (
    UserID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    Password VARCHAR(255) NOT NULL
);

-- ==============================
-- SELLERS TABLE
-- ==============================
CREATE TABLE sellers (
    SellerID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    ContactInfo VARCHAR(255)
);

-- ==============================
-- PRODUCTS TABLE
-- ==============================
CREATE TABLE products (
    ProductID INT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(150) NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    Stock INT NOT NULL,
    SellerID INT,
    FOREIGN KEY (SellerID) REFERENCES sellers(SellerID)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);

-- ==============================
-- CART TABLE
-- ==============================
CREATE TABLE cart (
    CartID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT,
    ProductID INT,
    Quantity INT DEFAULT 1,
    FOREIGN KEY (UserID) REFERENCES users(UserID)
        ON DELETE CASCADE,
    FOREIGN KEY (ProductID) REFERENCES products(ProductID)
        ON DELETE CASCADE
);

-- ==============================
-- PAYMENTS TABLE
-- ==============================
CREATE TABLE payments (
    PaymentID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT,
    CardType VARCHAR(50),
    CardNumber VARCHAR(255),
    NameOnCard VARCHAR(100),
    Expiry VARCHAR(10),
    FOREIGN KEY (UserID) REFERENCES users(UserID)
        ON DELETE CASCADE
);

-- ==============================
-- ORDERS TABLE
-- ==============================
CREATE TABLE orders (
    OrderID INT AUTO_INCREMENT PRIMARY KEY,
    UserID INT,
    OrderDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    Status VARCHAR(50),
    TotalAmount DECIMAL(10,2),
    FOREIGN KEY (UserID) REFERENCES users(UserID)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- ==============================
-- ORDER ITEMS TABLE
-- ==============================
CREATE TABLE orderItems (
    OrderItemID INT AUTO_INCREMENT PRIMARY KEY,
    OrderID INT,
    ProductID INT,
    Quantity INT NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (OrderID) REFERENCES orders(OrderID)
        ON DELETE CASCADE,
    FOREIGN KEY (ProductID) REFERENCES products(ProductID)
        ON DELETE CASCADE
);

-- ==============================
-- MESSAGES TABLE
-- ==============================
CREATE TABLE messages (
    MessageID INT AUTO_INCREMENT PRIMARY KEY,
    SenderID INT,
    ReceiverID INT,
    Content TEXT,
    Timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (SenderID) REFERENCES users(UserID)
        ON DELETE CASCADE,
    FOREIGN KEY (ReceiverID) REFERENCES users(UserID)
        ON DELETE CASCADE
);