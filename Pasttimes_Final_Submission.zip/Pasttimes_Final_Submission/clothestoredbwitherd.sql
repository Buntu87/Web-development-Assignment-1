-- ==============================
-- CREATE & USE DATABASE SAFELY
-- ==============================

-- Database creation/selection omitted to avoid parser issues in diagnostics.
-- Please create and select the database `clothestoredbwitherd` manually before importing.
-- CREATE DATABASE clothestoredbwitherd CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- USE clothestoredbwitherd;

-- ==============================
-- DROP TABLES (prevents errors on re-import)
-- ==============================
DROP TABLE IF EXISTS orderItems;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS sellers;
DROP TABLE IF EXISTS messages;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS cart;
DROP TABLE IF EXISTS payments;

-- ==============================
-- USERS TABLE
-- ==============================
CREATE TABLE users (
    UserID INT NOT NULL,
    Name VARCHAR(100) NOT NULL,
    Email VARCHAR(100) UNIQUE NOT NULL,
    Password VARCHAR(255) NOT NULL,
    PRIMARY KEY (UserID)
);

-- ==============================
-- SELLERS TABLE
-- ==============================
CREATE TABLE sellers (
    SellerID INT NOT NULL,
    Name VARCHAR(100) NOT NULL,
    ContactInfo VARCHAR(255),
    PRIMARY KEY (SellerID)
);

-- ==============================
-- PRODUCTS TABLE
-- ==============================
CREATE TABLE products (
    ProductID INT NOT NULL,
    Name VARCHAR(150) NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    Stock INT NOT NULL,
    SellerID INT,
    FOREIGN KEY (SellerID) REFERENCES sellers(SellerID),
    PRIMARY KEY (ProductID)
);

-- ==============================
-- CART TABLE
-- ==============================
CREATE TABLE cart (
    CartID INT NOT NULL,
    UserID INT,
    ProductID INT,
    Quantity INT DEFAULT 1,
    FOREIGN KEY (UserID) REFERENCES users(UserID)
        ON DELETE CASCADE,
    FOREIGN KEY (ProductID) REFERENCES products(ProductID)
        ON DELETE CASCADE,
    PRIMARY KEY (CartID)
);

-- ==============================
-- PAYMENTS TABLE
-- ==============================
CREATE TABLE payments (
    PaymentID INT NOT NULL,
    UserID INT,
    CardType VARCHAR(50),
    CardNumber VARCHAR(255),
    NameOnCard VARCHAR(100),
    Expiry VARCHAR(10),
    FOREIGN KEY (UserID) REFERENCES users(UserID)
        ON DELETE CASCADE,
    PRIMARY KEY (PaymentID)
);

-- ==============================
-- ORDERS TABLE
-- ==============================
CREATE TABLE orders (
    OrderID INT NOT NULL,
    UserID INT,
    OrderDate DATETIME DEFAULT CURRENT_TIMESTAMP,
    Status VARCHAR(50),
    TotalAmount DECIMAL(10,2),
    FOREIGN KEY (UserID) REFERENCES users(UserID),
    PRIMARY KEY (OrderID)
);

-- ==============================
-- ORDER ITEMS TABLE
-- ==============================
CREATE TABLE orderItems (
    OrderItemID INT NOT NULL,
    OrderID INT,
    ProductID INT,
    Quantity INT NOT NULL,
    Price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (OrderID) REFERENCES orders(OrderID)
        ON DELETE CASCADE,
    FOREIGN KEY (ProductID) REFERENCES products(ProductID)
        ON DELETE CASCADE,
    PRIMARY KEY (OrderItemID)
);

-- ==============================
-- MESSAGES TABLE
-- ==============================
CREATE TABLE messages (
    MessageID INT NOT NULL,
    SenderID INT,
    ReceiverID INT,
    Content TEXT,
    Timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (SenderID) REFERENCES users(UserID)
        ON DELETE CASCADE,
    FOREIGN KEY (ReceiverID) REFERENCES users(UserID)
        ON DELETE CASCADE,
    PRIMARY KEY (MessageID)
);

-- ==============================
-- SELLER REQUESTS TABLE
-- Sellers (or customers) can submit items they want to sell for admin review
-- ==============================
CREATE TABLE seller_requests (
    RequestID INT NOT NULL,
    UserID INT NULL,
    Name VARCHAR(150) NOT NULL,
    Brand VARCHAR(100),
    Description TEXT,
    ImagePath VARCHAR(255),
    Status VARCHAR(50) DEFAULT 'Pending',
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (UserID) REFERENCES users(UserID),
    PRIMARY KEY (RequestID)
);