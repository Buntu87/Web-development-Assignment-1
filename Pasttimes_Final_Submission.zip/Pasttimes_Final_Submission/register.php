<?php
session_start();
require_once 'db.php';

$message = "";

// If user is logged in, show profile edit; otherwise show registration form
if (isset($_SESSION['user_id'])) {
    $userId = intval($_SESSION['user_id']);
    // Load current user
    $stmt = $conn->prepare("SELECT UserID, Name, Email FROM users WHERE UserID = ?");
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $res = $stmt->get_result();
    $user = $res->fetch_assoc();
    $stmt->close();

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $update = $conn->prepare("UPDATE users SET Name = ?, Email = ? WHERE UserID = ?");
        $update->bind_param('ssi', $name, $email, $userId);
        if ($update->execute()) {
            $message = 'Profile updated.';
            $_SESSION['user_name'] = $name;
            $_SESSION['user_email'] = $email;
        } else {
            $message = 'Update failed.';
        }
        $update->close();
    }
} else {
    // Registration
    if (isset($_POST['register'])) {
        $username = mysqli_real_escape_string($conn, $_POST['username']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $password = $_POST['password'];
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $check = $conn->prepare("SELECT * FROM users WHERE Email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $result = $check->get_result();

        if ($result->num_rows > 0) {
            $message = "Email already exists!";
        } else {
            $stmt = $conn->prepare("INSERT INTO users (Name, Email, Password) VALUES (?, ?, ?)");
            $stmt->bind_param("sss", $username, $email, $hashedPassword);
            if ($stmt->execute()) {
                $message = "Registered Successfully!";
            } else {
                $message = "Error: " . $conn->error;
            }
            $stmt->close();
        }
        $check->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($_SESSION['user_id']) ? 'Profile' : 'Register'; ?></title>
<link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="header">
        <h2><?php echo isset($_SESSION['user_id']) ? 'Profile info' : 'Register'; ?></h2>
        <div>
            <a href="index.php">Home</a> | <a href="products.php">Products</a>
        </div>
    </div>

    <div class="container">
        <aside class="sidebar">
            <div class="avatar">
                <img src="images/avatar.png" alt="avatar" onerror="this.src='images/avatar.png'">
                <div>
                    <h3><?php echo htmlspecialchars($_SESSION['user_name'] ?? 'User'); ?></h3>
                    <div class="small"><?php echo htmlspecialchars($_SESSION['user_email'] ?? ''); ?></div>
                </div>
            </div>
            <nav class="account-nav">
                <a href="image/dashboard.php">Dashboard</a>
                <a href="orders.php">Orders</a>
                <a href="payments.php">Payment methods</a>
                <a class="active" href="register.php">Profile info</a>
                <a href="addresses.php">Addresses</a>
            </nav>
        </aside>

        <main class="content">
            <?php if (!empty($message)) echo '<div class="message">' . htmlspecialchars($message) . '</div>'; ?>

            <?php if (isset($_SESSION['user_id'])): ?>
                <form method="post" action="register.php">
                    <label>Name</label>
                    <input name="name" value="<?php echo htmlspecialchars($user['Name'] ?? ''); ?>" required>
                    <label>Email</label>
                    <input name="email" type="email" value="<?php echo htmlspecialchars($user['Email'] ?? ''); ?>" required>
                    <button type="submit" name="update_profile">Save</button>
                </form>
            <?php else: ?>
                <form action="register.php" method="post">
                    <input name="username" placeholder="Username" required>
                    <input name="email" type="email" placeholder="Email" required>
                    <input name="password" type="password" placeholder="Password" required>
                    <button type="submit" name="register">Register</button>
                </form>
            <?php endif; ?>

        </main>
    </div>

</body>
</html>
