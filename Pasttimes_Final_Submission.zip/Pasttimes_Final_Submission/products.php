<?php
session_start();
require_once 'db.php';

// Sample products to display (images may be local or external placeholders)
// Dresses for sale — all priced at R800.99 as requested
$products = [
    ['id' => 'd1', 'name' => 'Floral Evening Dress', 'price' => 'R800.99', 'local' => 'd1'],
    ['id' => 'd2', 'name' => 'Satin Party Dress', 'price' => 'R800.99', 'local' => 'd2'],
    ['id' => 'd3', 'name' => 'Cocktail Midi Dress', 'price' => 'R800.99', 'local' => 'd3'],
    ['id' => 'd4', 'name' => 'Lace Formal Dress', 'price' => 'R800.99', 'local' => 'd4'],
    ['id' => 'd5', 'name' => 'Chiffon Maxi Dress', 'price' => 'R800.99', 'local' => 'd5'],
    ['id' => 'd6', 'name' => 'Velvet Wrap Dress', 'price' => 'R800.99', 'local' => 'd6']
];

// Resolve local images if present (p1.jpg/png/webp etc.), otherwise fallback to placeholder
foreach ($products as &$p) {
    $localBase = $p['local'] ?? '';
    $found = '';
    if ($localBase) {
        $extensions = ['webp','jpg','jpeg','png','gif','avif'];
        foreach ($extensions as $ext) {
            $path = __DIR__ . '/images/' . $localBase . '.' . $ext;
            if (file_exists($path)) {
                $found = 'images/' . $localBase . '.' . $ext;
                break;
            }
        }
    }
    if ($found) {
        $p['image'] = $found;
    } elseif (!isset($p['image'])) {
        $p['image'] = 'https://via.placeholder.com/300?text=' . rawurlencode($p['name']);
    }
}
unset($p);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
            gap: 24px;
            padding: 28px;
            background: #ffffff;
            border-radius: 22px;
            box-shadow: 0 14px 35px rgba(9, 34, 83, 0.08);
        }
        .product-card {
            background: #f7f9fe;
            border: 2px solid #d9e2f2;
            border-radius: 18px;
            padding: 16px;
            text-align: center;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
            display: flex;
            flex-direction: column;
        }
        .product-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 18px 40px rgba(11, 63, 143, 0.15);
            border-color: #0b58e0;
        }
        .product-image {
            width: 100%;
            height: 220px;
            object-fit: cover;
            border-radius: 14px;
            border: 2px solid #dfe7f2;
            margin-bottom: 12px;
            cursor: pointer;
            transition: transform 0.2s ease;
        }
        .product-image:hover {
            transform: scale(1.02);
        }
        .product-name {
            background: #0b3d8f;
            color: #ffffff;
            padding: 10px 12px;
            border-radius: 12px;
            font-size: 0.95rem;
            font-weight: 700;
            margin-bottom: 8px;
            min-height: 40px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .product-price {
            font-size: 1.3rem;
            font-weight: 700;
            color: #0b3d8f;
            margin: 8px 0;
        }
        .add-to-cart-btn {
            width: 100%;
            margin-top: auto;
            padding: 12px 16px;
            background: #0b58e0;
            color: white;
            border: none;
            border-radius: 12px;
            font-weight: 700;
            cursor: pointer;
            transition: background 0.2s ease, transform 0.2s ease;
        }
        .add-to-cart-btn:hover {
            background: #0842a2;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <div class="header">
        <h2>Products</h2>
        <div>
            <a href="index.php">Home</a> |
            <a href="cart.php">Cart</a> |
            <a href="sell_request.php">Sell an Item</a> |
            <a href="login.php">Login</a> |
            <a href="register.php">Register</a>
        </div>
    </div>

    <div class="container" style="max-width: 1200px; margin: 0 auto 30px; padding: 0 16px;">
        <div class="products-grid">
            <?php foreach($products as $p): ?>
            <?php
                // Normalize image URL: prefix './' for local relative paths so links work consistently
                $img = $p['image'];
                if (!preg_match('#^https?://#i', $img)) {
                    $img = './' . ltrim($img, '/');
                }
            ?>
            <div class="product-card">
                <a href="<?php echo htmlspecialchars($img); ?>" target="_blank" rel="noopener noreferrer">
                    <img src="<?php echo htmlspecialchars($img); ?>" alt="<?php echo htmlspecialchars($p['name']); ?>" class="product-image">
                </a>
                <div class="product-name"><?php echo htmlspecialchars($p['name']); ?></div>
                <div class="product-price"><?php echo htmlspecialchars($p['price']); ?></div>
                <form method="post" action="cart.php" style="display:flex;flex-direction:column;">
                    <input type="hidden" name="product_id" value="<?php echo htmlspecialchars($p['id']); ?>">
                    <input type="hidden" name="name" value="<?php echo htmlspecialchars($p['name']); ?>">
                    <input type="hidden" name="price" value="<?php echo htmlspecialchars($p['price']); ?>">
                    <button type="submit" class="add-to-cart-btn">Add to Cart</button>
                </form>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Add All Dresses to Cart button -->
        <div style="max-width:1200px;margin:18px auto 40px;padding:0 16px;">
            <form method="post" action="cart.php" style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
                <?php foreach($products as $p): ?>
                    <input type="hidden" name="name[]" value="<?php echo htmlspecialchars($p['name']); ?>">
                    <input type="hidden" name="price[]" value="<?php echo htmlspecialchars($p['price']); ?>">
                    <input type="hidden" name="product_id[]" value="<?php echo htmlspecialchars($p['id']); ?>">
                <?php endforeach; ?>
                <input type="hidden" name="add_all" value="1">
                <button type="submit" style="padding:12px 18px;background:#28a745;color:#fff;border:none;border-radius:12px;font-weight:700;">Add All Dresses to Cart (R800.99 each)</button>
            </form>
        </div>
    </div>
</body>
</html>