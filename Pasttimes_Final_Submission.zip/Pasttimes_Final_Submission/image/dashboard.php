<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$userName = $_SESSION['user_name'] ?? 'Guest';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="../style.css">
    <style>
        .welcome-card { background: linear-gradient(90deg,#f7fbff,#eef6ff); padding:18px; border-radius:12px; margin-bottom:16px; border:1px solid #e6f0ff; }
        .welcome-card h3 { margin:0 0 6px 0; }
        .stats { display:flex; gap:12px; margin-bottom:18px; flex-wrap:wrap; }
        .stat { flex:1 1 160px; background:#fff; border-radius:12px; padding:16px; border:1px solid #eef6ff; }
        .stat h4 { margin:0 0 8px 0; font-size:0.9rem; color:#5b6b81; }
        .stat .num { font-size:1.6rem; font-weight:800; color:#0b3d8f; }
        .recent-orders table { width:100%; border-collapse:collapse; }
        .recent-orders th, .recent-orders td { padding:10px 12px; border-bottom:1px solid #eef6ff; text-align:left; }
    </style>
</head>
<body>
        <div class="header">
            <h2>My Account</h2>
            <div>
                <a href="../products.php">Shop</a>
                <a href="../upload.php">Sell Item</a>
                <a href="../logout.php">Logout</a>
            </div>
        </div>

        <div class="container">
            <aside class="sidebar">
                <div class="avatar">
                    <img src="../images/avatar.png" alt="avatar" onerror="this.src='../images/avatar.png'">
                    <div>
                        <h3><?php echo htmlspecialchars($userName); ?></h3>
                        <div class="small"><?php echo htmlspecialchars($_SESSION['user_email'] ?? ''); ?></div>
                    </div>
                </div>
                <nav class="account-nav">
                    <a class="active" href="dashboard.php">Dashboard</a>
                    <a href="../orders.php">Orders</a>
                    <a href="../payments.php">Payment methods</a>
                    <a href="../register.php">Profile info</a>
                    <a href="../addresses.php">Addresses</a>
                </nav>
            </aside>

            <main class="content">
                <h3>Welcome to your dashboard, <?php echo htmlspecialchars($userName); ?></h3>
                <?php
                // Fetch some quick stats and recent orders
                require_once __DIR__ . '/../db.php';
                $uid = intval($_SESSION['user_id']);
                $orderCount = 0;
                $pendingCount = 0;
                $recent = [];
                try {
                    $res = $conn->query("SELECT COUNT(*) as c FROM orders WHERE UserID = $uid");
                    if ($res) { $orderCount = (int)$res->fetch_assoc()['c']; }

                    $res2 = $conn->query("SELECT COUNT(*) as c FROM orders WHERE UserID = $uid AND Status LIKE '%Placed%'");
                    if ($res2) { $pendingCount = (int)$res2->fetch_assoc()['c']; }

                    $r = $conn->query("SELECT OrderID, OrderDate, Status, TotalAmount FROM orders WHERE UserID = $uid ORDER BY OrderDate DESC LIMIT 5");
                    if ($r) { $recent = $r->fetch_all(MYSQLI_ASSOC); }
                } catch (mysqli_sql_exception $e) {
                    // If the orders table doesn't exist or another DB error occurs, fallback to empty/defaults
                    $orderCount = 0;
                    $pendingCount = 0;
                    $recent = [];
                }
                ?>

                <div class="welcome-card">
                    <h3>Hello, <?php echo htmlspecialchars($userName); ?></h3>
                    <p class="small">Here is a quick overview of your account and recent activity.</p>
                    <div style="margin-top:12px;">
                        <a href="../upload.php" class="button">Sell an item</a>
                        <?php if (!empty($_SESSION['is_admin']) && $_SESSION['is_admin'] === true): ?>
                            <a href="../admin/dashboard.php" class="button" style="background:#6f42c1;margin-left:8px;">Admin Panel</a>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="stats">
                    <div class="stat">
                        <h4>Total orders</h4>
                        <div class="num"><?php echo $orderCount; ?></div>
                    </div>
                    <div class="stat">
                        <h4>Pending</h4>
                        <div class="num"><?php echo $pendingCount; ?></div>
                    </div>
                    <div class="stat">
                        <h4>Saved addresses</h4>
                            <div class="num">
                                <?php
                                try {
                                    $c = $conn->query("SELECT COUNT(*) as c FROM addresses WHERE UserID = $uid");
                                    echo $c ? intval($c->fetch_assoc()['c']) : 0;
                                } catch (mysqli_sql_exception $e) {
                                    echo 0;
                                }
                                ?>
                            </div>
                    </div>
                </div>

                <div class="recent-orders">
                    <h4>Recent orders</h4>
                    <?php if (empty($recent)): ?>
                        <p>No recent orders.</p>
                    <?php else: ?>
                        <table>
                            <thead><tr><th>Order #</th><th>Date</th><th>Status</th><th>Total</th></tr></thead>
                            <tbody>
                            <?php foreach($recent as $row): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($row['OrderID']); ?></td>
                                    <td><?php echo htmlspecialchars($row['OrderDate']); ?></td>
                                    <td><?php echo htmlspecialchars($row['Status']); ?></td>
                                    <td>R<?php echo number_format(floatval($row['TotalAmount']),2); ?></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </main>
        </div>
    </body>
    </html>