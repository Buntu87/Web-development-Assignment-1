<?php
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

$userName = $_SESSION['user_name'] ?? 'Guest';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background: #f5f5f5;
        }
        .dashboard {
            max-width: 500px;
            margin: 0 auto;
            background: #fff;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 0 12px rgba(0,0,0,0.08);
        }
        .dashboard h2 {
            margin-bottom: 20px;
        }
        .dashboard a {
            display: inline-block;
            margin-right: 10px;
            margin-bottom: 10px;
            padding: 10px 14px;
            background: #4CAF50;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
        }
        .dashboard a:hover {
            background: #45a049;
        }
    </style>
</head>
<body>
    <div class="dashboard">
        <h2>Welcome to your dashboard, <?php echo htmlspecialchars($userName); ?></h2>
        <nav>
            <a href="../products.php">Shop</a>
            <a href="../upload.php">Sell Item</a>
            <a href="../logout.php">Logout</a>
        </nav>
    </div>
</body>
</html>