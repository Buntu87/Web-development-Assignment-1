<?php
session_start();
require_once 'db.php';

$message = "";

if(isset($_POST['login'])){
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM users WHERE Email = '$email'";
    $result = mysqli_query($conn, $sql);

    if(mysqli_num_rows($result) > 0){
        $row = mysqli_fetch_assoc($result);

        // Check password with hash comparison
        if(password_verify($password, $row['Password'])){

            $_SESSION['user_id'] = $row['UserID'];
            $_SESSION['user_name'] = $row['Name'];
            $_SESSION['is_admin'] = ($row['Name'] === 'Admin User') ? true : false;
            
            if($_SESSION['is_admin']){
                header("Location: admin/dashboard.php");
            }
            else{
                header("Location: index.php");
            }
            exit();

        } else {
            $message = "Incorrect password!";
        }
    } else {
        $message = "User not found!";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <style>
        body{
            font-family: Arial;
            display:flex;
            justify-content:center;
            align-items:center;
            height:100vh;
            background:#f5f5f5;
        }
        .login{
            background: darkgray;
            padding: 35px;
            border-radius: 10px;
        }
        .login input{
            display: block;
            border-radius: 15px;
            margin-top: 10px;
            margin-bottom: 10px;
            padding:10px;
            width: 100%;
        }
        .login a{
            color: blue;
        }
        button{
            padding:10px;
            background:blue;
            color:white;
            border:none;
            width:100%;
        }
    </style>
</head>
<body>

<div class="login">
    <form method="POST">
        <h2>Login</h2>

        <p style="color:red;"><?php echo $message; ?></p>

        <input type="email" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>

        <button type="submit" name="login">Login</button>

        <p>Don't have an account?
        <a href="register.php">Create account</a></p>
    </form>
</div>

</body>
</html>