<?php
session_start();
include "db.php";

$sql = "SELECT * FROM products";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pastimes</title>

    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background: #f8f8f8;
            color: #111;
        }

        .header {
            position: fixed;
            top: 0;
            width: 100%;
            background-color: gray;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 40px;
            z-index: 1000;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .logo img {
            height: 40px;
        }

        .header a {
            text-decoration: none;
            color: white;
            font-weight: bold;
        }

        nav ul {
            display: flex;
            list-style: none;
        }

        nav li {
            margin-left: 30px;
        }

        nav a:hover {
            color: lightblue;
        }

        .content {
            margin-top: 140px;
            text-align: center;
            padding: 20px;
        }

        .image-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 15px;
            margin-top: 30px;
        }

        .product-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-top: 30px;
            justify-items: center;
        }

        .product-card {
            width: 100%;
            max-width: 320px;
            background: #fff;
            border-radius: 16px;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
            padding: 18px;
            text-align: center;
        }

        .product-card a img {
            width: 100%;
            height: 240px;
            object-fit: cover;
            border-radius: 14px;
            display: block;
        }

        .buy-button {
            display: inline-block;
            margin-top: 14px;
            padding: 12px 22px;
            border-radius: 999px;
            background-color: #0077cc;
            color: white;
            text-decoration: none;
            font-weight: bold;
        }

        .buy-button:hover {
            background-color: #005fa3;
        }

        .img-box {
            background: #fff;
            padding: 12px;
            border-radius: 12px;
            box-shadow: 0 6px 18px rgba(0, 0, 0, 0.08);
            text-align: left;
        }

        .img-box img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            border-radius: 10px;
        }

        .img-box .price {
            margin-top: 10px;
            font-size: 16px;
            font-weight: 700;
            color: #111;
        }

        .img-box .name {
            margin-top: 6px;
            font-size: 14px;
            color: #555;
        }

        @media (max-width: 900px) {
            .image-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 600px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
            }

            nav ul {
                flex-direction: column;
                width: 100%;
                margin-top: 10px;
            }

            nav li {
                margin: 10px 0;
            }

            .image-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
<header class="header">
    <div class="logo">
        <a href="index.php">Pastimes</a>
        <img src="image/Producting/360_F_303369705_Ap2BaZOlOMHqwtWmtNb1TBlgRmXtgtoh.jpg" alt="Logo">
    </div>
    <nav>
        <ul>
            <?php if (!isset($_SESSION['user_id'])): ?>
            <li><a href="login.php">Login</a></li>
            <li><a href="register.php">Register</a></li>
            <?php endif; ?>
            <li><a href="products.php">Shop</a></li>
            <?php if (isset($_SESSION['user_id'])): ?>
            <li><a href="admin/dashboard.php">Dashboard</a></li>
            <?php endif; ?>
        </ul>
    </nav>
</header>
<div class="content">
    <h1>Pastimes Store</h1>
    <div class="product-grid">
        <div class="product-card">
            <a href="products.php">
                <img src="image/Producting/360_F_303369705_Ap2BaZOlOMHqwtWmtNb1TBlgRmXtgtoh.jpg" alt="Featured Jacket">
            </a>
            <p class="price">R10.99</p>
            <a href="products.php" class="buy-button">Shop Now</a>
        </div>
        <div class="product-card">
            <a href="products.php">
                <img src="image/Producting/fashion-1979136_1280.jpg" alt="Featured Wear">
            </a>
            <p class="price">R10.99</p>
            <a href="products.php" class="buy-button">Shop Now</a>
        </div>
    </div>
    <div class="image-grid">
        <?php if ($result && mysqli_num_rows($result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <div class="img-box">
                    <img src="<?php echo htmlspecialchars($row['Image'] ?? 'image/Producting/360_F_303369705_Ap2BaZOlOMHqwtWmtNb1TBlgRmXtgtoh.jpg'); ?>"
                         alt="<?php echo htmlspecialchars($row['Name'] ?? 'Product'); ?>">
                    <p class="price">$<?php echo htmlspecialchars(number_format($row['Price'] ?? 0, 2)); ?></p>
                    <p class="name"><?php echo htmlspecialchars($row['Name'] ?? 'Unnamed product'); ?></p>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No products found.</p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
