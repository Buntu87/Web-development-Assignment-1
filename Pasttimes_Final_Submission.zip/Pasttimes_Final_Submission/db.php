<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$servername = 'localhost';
$username = 'root';
$password = '';
$database = 'clothestoredbwitherd';

try {
    $conn = @new mysqli($servername, $username, $password, $database);
    if ($conn->connect_errno) {
        // Try to connect without selecting a database to create it
        $tmp = new mysqli($servername, $username, $password);
        if ($tmp->connect_errno) {
            throw new mysqli_sql_exception('Could not connect to MySQL server: ' . $tmp->connect_error);
        }

        // Create database if it does not exist
        $created = $tmp->query("CREATE DATABASE IF NOT EXISTS `$database` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        if ($created === false) {
            throw new mysqli_sql_exception('Could not create database: ' . $tmp->error);
        }

        // Import schema from SQL file if tables are missing
        $sqlFile = __DIR__ . '/clothestoredbwitherd.sql';
        if (file_exists($sqlFile)) {
            $schema = file_get_contents($sqlFile);
            // Remove comments and split statements naively on ';'
            $lines = preg_split('/\n/', $schema);
            $filtered = [];
            foreach ($lines as $line) {
                $trim = trim($line);
                if ($trim === '' || strpos($trim, '--') === 0) continue;
                $filtered[] = $line;
            }
            $schemaClean = implode("\n", $filtered);
            $statements = array_filter(array_map('trim', explode(';', $schemaClean)));
            // Select the newly created database
            $tmp->select_db($database);
            foreach ($statements as $stmt) {
                // skip short statements
                if (strlen($stmt) < 5) continue;
                $tmp->query($stmt);
            }
        }

        $tmp->close();

        // Now connect to the database
        $conn = new mysqli($servername, $username, $password, $database);
        if ($conn->connect_errno) {
            throw new mysqli_sql_exception('Could not connect to database after creation: ' . $conn->connect_error);
        }
    }

    $conn->set_charset('utf8mb4');
} catch (mysqli_sql_exception $e) {
    die('Database connection failed: ' . $e->getMessage());
}
?>